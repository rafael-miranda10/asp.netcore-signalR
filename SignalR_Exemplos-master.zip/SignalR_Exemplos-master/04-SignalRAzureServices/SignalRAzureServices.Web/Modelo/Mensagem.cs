﻿namespace SignalRAzureServices.Web.Modelo
{
    public class Mensagem
    {
        public string Nome { get; set; }
        public string Msg { get; set; }
    }
}
