export const environment = {
  production: true,
  url: 'http://localhost:5000'
};
