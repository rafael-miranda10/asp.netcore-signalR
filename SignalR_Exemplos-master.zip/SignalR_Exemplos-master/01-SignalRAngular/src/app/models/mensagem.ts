export class Mensagem {
    public nome: string;
    public msg: string;
    public maquina: string;
}
