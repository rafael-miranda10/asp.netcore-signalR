﻿namespace signalr_best_practice_core.Interfaces.Repositories.Base
{
    public interface IDatabaseInitializer
    {
        void Initialize();
    }
}
