﻿namespace signalr_best_practice_core.Interfaces.Entities
{
    public interface IUserEntity
    {
        string UserId { get; set; }
    }
}
