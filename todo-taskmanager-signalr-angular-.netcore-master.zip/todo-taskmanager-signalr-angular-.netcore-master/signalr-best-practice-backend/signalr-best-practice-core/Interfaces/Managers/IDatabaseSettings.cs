﻿namespace signalr_best_practice_core.Interfaces.Managers
{
    public interface IDatabaseSettings
    {
        string GetConnectionString();
    }
}
