﻿using Microsoft.AspNetCore.SignalR;

namespace signalr_nest_practice_hub.Hubs
{
    public class NotificationHub : Hub
    {
    }
}
