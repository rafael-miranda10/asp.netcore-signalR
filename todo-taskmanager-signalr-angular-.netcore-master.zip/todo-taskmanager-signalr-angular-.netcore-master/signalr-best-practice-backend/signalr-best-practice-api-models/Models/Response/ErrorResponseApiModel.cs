﻿using signalr_best_practice_api_models.Models.Base;

namespace signalr_best_practice_api_models.Models.Response
{
    public class ErrorResponceApiModel<T> : BaseResponseApiModel
    {
    }
}
