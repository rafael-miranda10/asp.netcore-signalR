export interface ISignInResponse{
    id: string;
    token: string;
    refresh_token: string;
    token_life_date: Date;
}