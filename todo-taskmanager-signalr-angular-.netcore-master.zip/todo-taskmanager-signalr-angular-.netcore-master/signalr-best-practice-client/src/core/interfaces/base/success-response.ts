export interface ISuccessResponse{
    response: string;
    id: string;
}