export interface IUserProfile{
    id: string,
    first_name: string,
    second_name: string,
}