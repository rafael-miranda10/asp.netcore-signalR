export class RegistrationModel{
    public login: string;
    public password: string;
    public user_name: string;
}