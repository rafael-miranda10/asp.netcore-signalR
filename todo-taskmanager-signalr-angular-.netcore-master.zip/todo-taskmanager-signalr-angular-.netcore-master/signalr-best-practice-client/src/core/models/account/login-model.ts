export class LoginModel{
    public login: string;
    public password: string;
}