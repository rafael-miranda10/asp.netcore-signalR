import { ToDoTaskStatusEnum } from '../enum';

export class ToDoTaskChangeProgressstatusModel{
    public id: string;
    public progress_status: ToDoTaskStatusEnum;
}