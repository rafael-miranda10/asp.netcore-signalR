# ScrumPoker

Sample on how to use signalR with React.

![Scrum](https://raw.githubusercontent.com/vikas0sharma/ScrumPoker/master/images/1.gif)
![Scrum](https://raw.githubusercontent.com/vikas0sharma/ScrumPoker/master/images/2.gif)
![Scrum](https://raw.githubusercontent.com/vikas0sharma/ScrumPoker/master/images/3.gif)
![Scrum](https://raw.githubusercontent.com/vikas0sharma/ScrumPoker/master/images/4.gif)
![Scrum](https://raw.githubusercontent.com/vikas0sharma/ScrumPoker/master/images/5.gif)

# Steps to run
1. Run API project in Visual Studio 2019.
2. Restore packages by running yarn command from clientapp folder.
3. Run yarn start command to run clientapp.
