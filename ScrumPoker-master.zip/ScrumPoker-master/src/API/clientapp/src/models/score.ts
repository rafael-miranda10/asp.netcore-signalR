export interface Score {
  point: string;
  sum: number;
}
