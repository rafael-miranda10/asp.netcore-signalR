﻿namespace API
{
    public class APISettings
    {
        public string ConnectionString { get; set; }
    }
}
